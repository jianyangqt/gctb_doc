# GCTB
Genome-wide Complex Trait Bayesian analysis

### Overview
[GCTB](http://cnsgenomics.com/software/gctb) is a C++ software tool that comprises Bayesian mixed linear models for complex trait analyses using genome-wide SNPs.

### How to run GCTB 1.0 

Use the command below (with the test dataset): 

`gctb --bfile data/uk10k_chr1_1mb --pheno data/test.phen --bayes S --chain-length 1100 --burn-in 100 --out test`

An alternative way to run the program with the parameter settings is to use a input parameter file: 

`gctb --inp-file test.inp`

