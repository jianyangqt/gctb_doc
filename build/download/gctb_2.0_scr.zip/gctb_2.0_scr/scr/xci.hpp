//
//  xci.hpp
//  gctb
//
//  Created by Jian Zeng on 27/10/2016.
//  Copyright © 2016 Jian Zeng. All rights reserved.
//

#ifndef xci_hpp
#define xci_hpp

#include <stdio.h>
#include "gctb.hpp"

class XCI {
public:
    unsigned numKeptMales;
    unsigned numKeptFemales;
    
    XCI(){
        numKeptMales   = 0;
        numKeptFemales = 0;
    }
    
    void inputIndInfo(Data &data, const string &bedFile, const string &phenotypeFile, const string &keepIndFile,
                      const unsigned keepIndMax, const unsigned mphen, const string &covariateFile);
    void sortIndBySex(vector<IndInfo*> &indInfoVec);
    void restoreFamFileOrder(vector<IndInfo*> &indInfoVec);
    void inputSnpInfo(Data &data, const string &bedFile, const string &includeSnpFile, const string &excludeSnpFile,
                      const unsigned includeChr, const bool readGenotypes);
    void readBedFile(Data &data, const string &bedFile);

    Model* buildModel(Data &data, const string &bayesType, const float heritability, const float pi, const float piAlpha, const float piBeta, const bool estimatePi, const float piNDC);
    void simu(Data &data, const unsigned numQTL, const float heritability, const float probNDC, const bool removeQTL, const string &title);
    void outputResults(const Data &data, const vector<McmcSamples*> &mcmcSampleVec, const string &title);
};


class BayesCXCI : public BayesC {
public:
    // y = mu + sum_j Z_j beta_j delta_j + e
    // For males,   Z_mj = X_mj
    // For females, Z_fj = X_fj with prob. p (under NDC model) or 0.5*X_fj with prob. 1-p (under FDC model)
    // p ~ U(0,1) or Beta(a,b) is the prob. of NDC model, in other word, the proportion of SNPs that escape from XCI
    // beta_j ~ N(0, sigma^2); sigma^2 ~ scaled-inverse chi-square
    // delta_j ~ Bernoulli(pi)
    
    class ProbNDC : public Parameter, public Stat::Beta {
    public:
        const float alpha;
        const float beta;
        
        ProbNDC(const float p): Parameter("PiNDC"), alpha(1), beta(1){  // conditional probability on nonzero SNPs, uniform prior
            value = p;
        }
        
        void sampleFromFC(const unsigned numSnps, const unsigned numNDC);
    };
        
    class Gamma : public ParamSet {
    public:
        Gamma(const vector<string> &header): ParamSet("Gamma", header){};
    };
    
    class SnpEffects : public BayesC::SnpEffects {
    public:
        SnpEffects(const vector<string> &header): BayesC::SnpEffects(header, "Gibbs"){};
        
        void sampleFromFC(VectorXf &ycorrm, VectorXf &ycorrf, const MatrixXf &Z, const VectorXf &ZPZdiag, const VectorXf &ZPZdiagMale,
                          const VectorXf &ZPZdiagFemale, const unsigned nmale, const unsigned nfemale, const float p,
                          const float sigmaSq, const float pi, const float varem, const float varef, VectorXf &gamma, VectorXf &ghatm, VectorXf &ghatf);
    };
    
    class ScaleVar : public BayesC::ScaleVar {
    public:
        const float sum2pq;
        
        ScaleVar(const float sum2pq, const float val): BayesC::ScaleVar(val), sum2pq(sum2pq){}
        
        void compute(const float vg, const float pi, float &scaleVar){
            value = 0.5f*vg/(sum2pq*pi);
            scaleVar = value;
        };
    };
    
    class Rounding : public BayesC::Rounding {
    public:
        Rounding(): BayesC::Rounding(){}
        void computeYcorr(const VectorXf &y, const MatrixXf &X, const MatrixXf &Z,
                          const VectorXf &gamma, const unsigned nmale, const unsigned nfemale,
                          const VectorXf &fixedEffects, const VectorXf &snpEffects,
                          VectorXf &ycorrm, VectorXf &ycorrf);
    };
    
    unsigned nmale, nfemale;
    float genVarPrior;
    float piPrior;
    
    ProbNDC piNDC;
    Gamma gamma;   // indicator variable with 1: NDC, 0: FDC
    SnpEffects snpEffects;
    ScaleVar scale;
    Rounding rounding;

    VectorXf ycorrm;
    VectorXf ycorrf;
    VectorXf ghatm;
    VectorXf ghatf;

    ResidualVar varem;
    ResidualVar varef;
    GenotypicVar vargm;
    GenotypicVar vargf;
    Heritability hsqm;
    Heritability hsqf;
    
    VectorXf ZPZdiagMale;
    VectorXf ZPZdiagFemale;
    
    BayesCXCI(const Data &data, const float varGenotypic, const float varResidual, const float pival, const float piAlpha, const float piBeta, const bool estimatePi, const float piNDCval, const unsigned nmale, const unsigned nfemale, const bool message = true):
    BayesC(data, varGenotypic, varResidual, pival, piAlpha, piBeta, estimatePi, false, "Gibbs", false),
    ycorrm(data.y.head(nmale)),
    ycorrf(data.y.tail(nfemale)),
    piNDC(piNDCval),
    gamma(data.snpEffectNames),
    snpEffects(data.snpEffectNames),
    scale(data.snp2pq.sum(), sigmaSq.scale),
    genVarPrior(varGenotypic),
    piPrior(pival),
    nmale(nmale), nfemale(nfemale),
    varem(varResidual, nmale, "ResVarM"),
    varef(varResidual, nfemale, "ResVarF"),
    vargm(varGenotypic, "GenVarM"),
    vargf(varGenotypic, "GenVarF"),
    hsqm("hsqM"),
    hsqf("hsqF") {

        ZPZdiagMale = data.Z.block(0, 0, nmale, data.numIncdSnps).colwise().squaredNorm();
        ZPZdiagFemale = data.Z.block(nmale, 0, nfemale, data.numIncdSnps).colwise().squaredNorm();

        // MPI
//        ZPZdiagMale.setZero(data.numIncdSnps);
//        ZPZdiagFemale.setZero(data.numIncdSnps);
//        VectorXf my_ZPZdiagMale   = data.Z.block(0, 0, nmale, data.numIncdSnps).colwise().squaredNorm();
//        VectorXf my_ZPZdiagFemale = data.Z.block(nmale, 0, nfemale, data.numIncdSnps).colwise().squaredNorm();
//        MPI_Allreduce(&my_ZPZdiagMale[0], &ZPZdiagMale[0], data.numIncdSnps, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
//        MPI_Allreduce(&my_ZPZdiagFemale[0], &ZPZdiagFemale[0], data.numIncdSnps, MPI_FLOAT, MPI_SUM, MPI_COMM_WORLD);
        
        gamma.values.setZero(data.numIncdSnps);
        paramSetVec = {&snpEffects, &gamma, &fixedEffects};
        paramVec = {&pi, &nnzSnp, &piNDC, &sigmaSq, &vargm, &vargf, &varem, &varef, &hsqm, &hsqf};
        paramToPrint = {&pi, &nnzSnp, &piNDC, &sigmaSq, &vargm, &vargf, &varem, &varef, &hsqm, &hsqf, &rounding};
//        if (message && myMPI::rank==0)
        if (message)
            cout << "\nBayesCXCI model fitted." << endl;
    }
    
    void sampleUnknowns(void);
};


class BayesBXCI : public BayesCXCI {
    // BayesB prior for the SNP effects.
public:
    
    class SnpEffects : public BayesB::SnpEffects {
    public:
        SnpEffects(const vector<string> &header): BayesB::SnpEffects(header){};
        
        void sampleFromFC(VectorXf &ycorr, const MatrixXf &Z, const VectorXf &ZPZdiag, const VectorXf &ZPZdiagMale,
                          const VectorXf &ZPZdiagFemale, const unsigned nmale, const unsigned nfemale, const float p,
                          const VectorXf &sigmaSq, const float pi, const float vare, VectorXf &gamma, VectorXf &ghat);
    };

    SnpEffects snpEffects;
    BayesB::VarEffects sigmaSq;

    BayesBXCI(const Data &data, const float varGenotypic, const float varResidual, const float pival, const float piAlpha, const float piBeta, const bool estimatePi, const float piNDCval, const unsigned nmale, const unsigned nfemale, const bool message = true):
    BayesCXCI(data, varGenotypic, varResidual, pival, piAlpha, piBeta, estimatePi, piNDCval, nmale, nfemale, false),
    snpEffects(data.snpEffectNames),
    sigmaSq(varGenotypic, data.snp2pq, pival)
    {
        paramSetVec = {&snpEffects, &gamma, &fixedEffects};
        paramVec = {&pi, &nnzSnp, &piNDC, &scale, &vare, &varg, &hsq};
        paramToPrint = {&pi, &nnzSnp, &piNDC, &scale, &vare, &varg, &hsq, &rounding};
//        if (message && myMPI::rank==0)
        if (message)
            cout << "\nBayesBXCI model fitted." << endl;
    }
    
    void sampleUnknowns(void);

};


#endif /* xci_hpp */
